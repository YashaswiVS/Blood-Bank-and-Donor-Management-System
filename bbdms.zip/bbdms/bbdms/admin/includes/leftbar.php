<nav class="ts-sidebar">
	<ul class="ts-sidebar-menu">
		<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
		
		<li><a href="#"><i class="fa fa-files-o"></i> Blood Group</a>
		<ul>
			<li><a href="add-bloodgroup.php">Add Blood Group</a></li>
			<li><a href="manage-bloodgroup.php">Manage Blood Group</a></li>
		</ul>
		</li>

		<li><a href="#"><i class="fa fa-users"></i> Blood Donor</a>
		<ul>
			<li><a href="add-donor.php">Add Donor</a></li>
			<li><a href="donor-list.php">Donor List</a></li>
		</ul>
		</li>
		
		<li><a href="request.php"><i class="fa fa-files-o"></i>Blood Requests</a></li>


	</ul>
</nav>