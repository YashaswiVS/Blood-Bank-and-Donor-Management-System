  
  
  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Blood Bank & Donor Management System 2022</p>
        </div>
        <!-- /.container -->
    </footer>